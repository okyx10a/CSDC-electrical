 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\EMA\ExportFolder\0\220330\Output\AltiumV14\AltiumV14.lia
 
 
To import your new library part to PCAD / ACCEL:

1. Start the Library Manager.
2. Select "Library" from the menu at the top of the screen.
3. Select "Translate"
4. Select the source file as the one we have sent you.
5. Specify where you would like to store the destination file.
6. Select the source Format as "PCAD ASCII".
7. Selcet the destination as "PCAD Binary"
8. Translate.

You may want to move the individual footprints,components and
symbols to a larger library.  This can be done with the
"Library"/"Copy" command at the top of the screen.

To import your new library parts into Protel DXP/Altium:

1. Start Protel DXP/Altium.
2. Select File/New/PCB Library.
3. Select File/Import
4. Browse to the included *.lia ile and select it.


For additional information, please visit this site:
http://www.accelerated-designs.com/help/PCAD_Accel_Import.html

If you're exporting to Altium, visit this site for more information:
http://www.accelerated-designs.com/help/Altium_import.html

To view a video, please visit:
http://youtu.be/sJ1KhFu3wl4
 
 


Ultra Librarian Gold 8.2.186 Process Report


Message - Padstack "EX6Y6D0TA" Shape(4) is a CIRCLE with no diameter.

TextStyle count:  25
Padstack count:   1
Pattern count:    1
Symbol count:     1
Component count:  1

Export

SolderPaste and SolderMask data have been removed from the follow pad styles:
	"EX6Y6D0TA"
